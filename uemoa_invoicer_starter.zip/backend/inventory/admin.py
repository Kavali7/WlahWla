from django.contrib import admin
from .models import Supplier, StockMovement
admin.site.register(Supplier)
admin.site.register(StockMovement)
